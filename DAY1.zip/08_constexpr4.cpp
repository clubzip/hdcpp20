#include <vector>
#include <string>
#include <numeric>

int main()
{
	std::vector v = { 1,2,3,4,5,6,7,8,9,10 };

	int c = std::accumulate(std::begin(v), std::end(v), 0);

}
