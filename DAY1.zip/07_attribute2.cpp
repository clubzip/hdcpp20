
// likely

int foo(int i)
{
    int i = 0;
    i = 1;
    i = 2;

    if (i > 0)  
        i += 2;
    else
        i -= 2;

    return i;
}
int main()
{
    foo(10);
    return 0;
}
