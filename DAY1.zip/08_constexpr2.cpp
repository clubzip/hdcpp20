class Base
{
public:
	virtual int foo(int a, int b) { return a + b; }
};

class Derived : public Base
{
public:
	int foo(int a, int b) override { return a + b; }
};

int main()
{
	Derived d;
	int ret1 = d.foo(1, 2); 
	constexpr int ret2 = d.foo(1, 2);


	Base* p = &d;			
	int ret3 = p->foo(1, 2);
	constexpr int ret4 = p->foo(1, 2);	
}
