#include <iostream>
#include <vector>

int main()
{
	std::vector v1{ 1,2,3 };

	// legacy "for"  in C++98
	for (std::size_t i = 0; i < v1.size(); i++)
	{
		std::cout << v1[i] << ", ";
	}

	// "range-based for" in C++11 
	for (auto& e : v1 )
	{
		std::cout << e << ", ";
	}

}
