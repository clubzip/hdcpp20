#include <iostream>
#include <memory>

struct Empty
{
};

template<typename T1, typename T2> struct PAIR
{
	T1 first;
	T2 second;
};


int main()
{
	PAIR<Empty> p1;

	std::cout << sizeof(p1) << std::endl;
}