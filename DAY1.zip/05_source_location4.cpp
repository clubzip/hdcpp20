#include <iostream>
#include <source_location>


void print_info(std::source_location location = std::source_location::current())
{
    std::cout << "file     : " << location.file_name() << std::endl;
    std::cout << "function : " << location.function_name() << std::endl;
    std::cout << "line     : " << location.line() << std::endl;
    std::cout << "column   : " << location.column() << std::endl;
}

template<typename T> int foo(T&& arg)
{    
    // template �ν��Ͻ�ȭ�� ����� ��Ȯ�� �˰� �ʹ�.
    return 0;
}

int main()
{
    int n = 10;
    foo(n);
    foo(10);
}