#include <type_traits>

template<typename T> class Value
{
	T value;
public:	
	Value(T arg) {}
};

int main()
{
	Value v1{ 123 };		
	Value v2 = { 123 };		
}
