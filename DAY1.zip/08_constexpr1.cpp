#include <iostream>

int add(int a, int b)
{
	return a + b;
}

int main()
{
	int x = 1, y = 2;

	int arr1[add(1, 2)];
	int arr2[add(x, y)];

	int ret1 = add(x, y);
	int ret2 = add(1, 2); 
	

}
