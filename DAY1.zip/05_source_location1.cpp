#include <iostream>
#include <source_location>

int main()
{
	// C style => ��ũ��!
	std::cout << __FILE__ << std::endl;
	std::cout << __func__ << std::endl;	
	std::cout << __LINE__ << std::endl; 
}
