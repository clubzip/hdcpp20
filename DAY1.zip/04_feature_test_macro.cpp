#include <iostream>
#include <numbers>
#include <span>

int main()
{
	std::cout << "support concepts" << std::endl;

}
