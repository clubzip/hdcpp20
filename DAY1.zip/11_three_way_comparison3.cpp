#include <compare>
#include <cstring>

class String
{
    char* buff;
    int   size;
public:
    String(const char* s)
    {
        size = strlen(s);
        buff = new char[size + 1];
        strcpy(buff, s);
    }
    ~String() { delete[] buff; }
};
int main()
{
    String s1("ABCD");
    String s2("ABCXYZ");

    bool ret = s1 == s2; 

}
