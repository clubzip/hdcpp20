#include <iostream>



int* allocate(int size)
{
	return new int[size];
}

int main()
{
	allocate(10);
}
