#include <iostream>


int main()
{
    int a = 10, b = 20;

    bool ret1 = a < b;

}
