#include <string_view>

// using enum

enum COLOR { RED, GREEN, BLUE }; // C++98 

std::string_view to_string(COLOR color)
{
    switch (color)
    {     
        case RED:   return "red";
        case GREEN: return "green";
        case BLUE:  return "blue";
    }
    return "invalid color";
}
int main()
{
    std::string_view ret = to_string(RED);
}
