#include <iostream>
#include <string_view>
#include <source_location>

// "line ��ȣ : �޼���" ���·� �α� �Ϸ��� �Ѵ�.
void log1(std::string_view msg, int line = __LINE__)
{												    
	std::cout << line << " : " << msg << std::endl;
}


int main()
{
	log1("message1", __LINE__);
	log1("message2", __LINE__);
	log1("message1"); 
	log1("message2"); 
}




