#include <iostream>

// [[no_unique_address]]

struct Empty
{
};
Empty e;

struct Data1
{
    Empty e;
    int   n;
};

struct Data2 : public Empty
{
    int   n;
};

struct Data3
{
    Empty e;
    int   n;
};

int main()
{
    std::cout << sizeof(Empty) << std::endl; // ?
    std::cout << sizeof(Data1) << std::endl; // ?
    std::cout << sizeof(Data2) << std::endl; // ?
    std::cout << sizeof(Data3) << std::endl; // ?
}
