#include <iostream>
#include <algorithm>
#include <numeric>

// C++20 std::midpoint

int main()
{
	int n = std::midpoint(1, 11);

	std::cout << n << std::endl; // �߰��� ���ϱ�.
}
