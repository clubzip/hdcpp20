#include <iostream>
#include <vector>
#include <array>

// C++20 std::to_array
int main()
{
	int x[10]{ 1,2,3,4,5,6,7,8,9,10 };
	std::vector<int> v{ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
	std::array<int, 10>  a{ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 }; 

}
