#include <iostream>

class Sample
{
public:
	void f1(int a, int b)
	{
		std::cout << "f1" << std::endl;
	}
};

int main()
{
	Sample s;
	s.f1(1, 2);
}