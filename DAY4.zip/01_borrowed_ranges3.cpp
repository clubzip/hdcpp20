#include <iostream>

// variable template ���� - C++14 ����

constexpr int variable = 0;

template<typename T>
constexpr int made_year = 0;


int main()
{
	std::cout << variable  << std::endl;
	std::cout << made_year << std::endl;
}



