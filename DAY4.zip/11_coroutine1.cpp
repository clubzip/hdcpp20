#include <iostream>

// Step 1. �Ϲ� �Լ�
void foo()
{
	std::cout << "foo 1" << std::endl;
	std::cout << "foo 2" << std::endl;
}

int main()
{
	foo();
}
