#include <iostream>
#include <functional>

// deducing this ���� 3. recursive lambda 

int main()
{
    auto factorial = [](int n)
    {
        return n > 1 ? n * factorial(n - 1) : 1;
    };
}
