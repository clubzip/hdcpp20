#include <iostream>
#include <vector>
#include <ranges>
#include <string>
#include <string_view>

// check borrowed range



template<typename T> class take_view
{
	T& container;
	std::size_t count;
public:
	take_view(T& c, std::size_t sz) : container(c), count(sz) {}

	auto begin() { return container.begin(); }
	auto end() { return container.begin() + count; }
};



//-----------------------------------------------------------------

template<typename T> void check(T& c)
{
	std::cout << std::boolalpha;
}


int main()
{
	std::vector v{ 1, 2, 3, 4, 5 };
	
	take_view tv(v, 5);

}


