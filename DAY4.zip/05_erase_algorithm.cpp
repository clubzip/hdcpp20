#include <iostream>
#include <vector>
#include <algorithm>

int main()
{
	std::vector v = { 1,2,3,1,2,3,1,2,3,1 };

	// C++98 : erase-remove idioms 
	auto p = std::remove(v.begin(), v.end(), 3);

	for (auto n : v) 
		std::cout << n << ", ";

	std::cout << std::endl;
}
