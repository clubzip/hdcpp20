#include <iostream>

// 2. type requirement
template<typename T> 
concept C = requires 
{
    typename T::type; 
};


class A
{
public:
    using type = int;
};


int main()
{
    std::cout << C<A> << std::endl;
}