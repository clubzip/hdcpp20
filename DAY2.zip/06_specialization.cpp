#include <iostream>
#include <algorithm>
#include <type_traits>
#include <concepts>
#include <vector>
#include <ranges>

// Ŭ���� ���ø�
template<typename T> class Test
{
public:
	static void foo() { std::cout << "T" << std::endl; }
};

int main()
{
	Test<int>::foo();
	Test<int*>::foo();
	Test<double>::foo();
	Test<std::vector<int>>::foo();
	Test<std::vector<int>::iterator>::foo();
}
