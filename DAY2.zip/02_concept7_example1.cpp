#include <iostream>
#include <vector>
#include <list>
#include <algorithm>

int main()
{
	std::vector<int> v = { 1,2,3,4,5,6,7,8,9,10 };
	
	auto p = std::begin(v);

	// �ݺ��ڸ� 5ĭ �����ϰ� �ʹ�.


	std::cout << *p << std::endl;
}