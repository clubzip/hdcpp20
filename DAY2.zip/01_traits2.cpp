#include <iostream>

template<typename T> 
void foo(const T& value)
{
	if (? )
		std::cout << "pointer" << std::endl;
	else 
		std::cout << "not pointer" << std::endl;
}

int main()
{
	int n = 10;
	foo(n);
	foo(&n);
}