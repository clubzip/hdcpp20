#include <iostream>
#include <type_traits>

template<typename T>
T gcd(T a, T b)
{
	return 0; 
}
int main()
{
	gcd(10, 4);
	gcd(3.4, 4.2); 
}
