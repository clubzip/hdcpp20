#include <iostream>

template<typename T> void printv(const T& value)
{
	std::cout << value << std::endl;
}

int main()
{
	int n = 10;
	printv(n);
	printv(&n);
}