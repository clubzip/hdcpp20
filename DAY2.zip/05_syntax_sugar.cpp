#include <concepts>
#include <iostream>

// �⺻ ���.
template<typename T> 
void f1(T a) 
{
	std::cout << "f1" << std::endl;
}

int main()
{
	f1(10);
	f2(10);
	f3(10); 
	f4(10);
	f5(10);
}