#include <iostream>
#include <concepts>

template<typename T> 
concept C2 = requires(T x)
{
    x + 1;
};

int main()
{

}