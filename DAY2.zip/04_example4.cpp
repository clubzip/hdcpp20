#include <list>
#include <vector>
#include <concepts>
#include <algorithm>
#include <iostream>


template<typename T> class counted_iterator
{

};

int main()
{
	std::vector c = { 1,2,3,4,5,6,7,8,9,10 };
//	std::list   c = { 1,2,3,4,5,6,7,8,9,10 };

	std::counted_iterator ci(c.begin(), 5);
	++ci; 

	ci = ci + 1; // ?
}