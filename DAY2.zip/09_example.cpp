#include <iostream>
#include <coroutine>
#include <string_view>
#include <string>
#include <concepts>
#include <source_location>


void log() {}

template<typename T>
class Generator
{
public:
    class promise
    {
    public:
        T value = 0;

        std::suspend_always yield_value(T v) { value = v; return {}; } // co_yield

        Generator get_return_object()
        {
            auto coro = std::coroutine_handle<promise>::from_promise(*this);
            return { coro };
        };

        std::suspend_always initial_suspend() { log(); return {}; }
        std::suspend_always final_suspend() noexcept { log(); return {}; }
        void unhandled_exception() { log(); }
        void return_void() { log(); }  // for vc++


        promise() { log(); }
        ~promise() { log(); }

        void* operator new(std::size_t sz)
        {
            void* p = ::operator new(sz);
            log();
            return p;
        }
        void operator delete(void* p) noexcept
        {
            ::operator delete(p);
            log();
        }
    };

    using promise_type = promise;
    std::coroutine_handle<promise> coro;
    Generator(std::coroutine_handle<promise> coro) : coro(coro) {}

    ~Generator()
    {
        if (coro)
            coro.destroy();
    }
    int operator()()
    {
        if (!coro || !coro.done())
        {
            coro.resume();  // coroutine�� �����ϰ�
            return coro.promise().value; // promise �� ���� �� ��ȯ
        }
        return 0;
    }
    Generator() = default;

    // ���� ����
    Generator(const Generator&) = delete;
    Generator& operator=(const Generator&) = delete;

    // move ����
    Generator(Generator&& other) noexcept : coro{ other.coro }
    {
        other.coro = {};
    }
    Generator& operator=(Generator&& other) noexcept {
        if (this != &other) {
            if (coro) {
                coro.destroy();
            }
            coro = other.coro;
            other.coro = {};
        }
        return *this;
    }

    // Range-based for loop support.
    class Iter {
    public:
        void operator++() {
            coro.resume();
        }
        const T& operator*() const
        {
            return coro.promise().value;
        }
        bool operator==(std::default_sentinel_t) const {
            return !coro || coro.done();
        }

        explicit Iter(const std::coroutine_handle<promise> coro) :
            coro{ coro }
        {}

    private:
        std::coroutine_handle<promise> coro;
    };

    Iter begin() {
        if (coro) {
            coro.resume();
        }
        return Iter{ coro };
    }
    std::default_sentinel_t end() {
        return {};
    }

};

// Python �� range �� C++ �ڷ�ƾ�� ������ �Լ�.
Generator<int> range(int first, int last)
{
    while (first < last)
    {
        co_yield first++;
    }
}
/*
int main()
{
    auto g = range(10, 20); // 10 ~ 19

    std::cout << g() << std::endl; // 10
    std::cout << g() << std::endl; // 11
    std::cout << g() << std::endl; // 12

    // �Ǵ� �Ʒ� ó�� �ݺ��ڷε� �����մϴ�.
    auto p = std::begin(g);

    std::cout << *p << std::endl; // 13
    ++p;
    std::cout << *p << std::endl; // 14

    // �ᱹ ��ó�� begin/end, �׸��� �ݺ��ڰ� �����Ƿ� 
    // for ���� �������� �ֽ��ϴ�
    for (auto e : g)
        std::cout << e << std::endl;
}
*/

int main()
{
    for (int i : range(65, 90)) // �ᱹ for ( int i : Generator ��ü ) ����� �˴ϴ�.
    {
        std::cout << i << ' ';
    }
    std::cout << '\n';
}

// C++20 : Coroutine �����ӿ�ũ (��ӵ� �帧) �� ��ǥ �Ǿ����ϴ�.

// ���� ���� Generator ���� ������ "�� �����ؼ� ���̺귯���� �����ϸ� ���� ������� ?
// 
// C++23 ���� ��ǥ�� �����Դϴ�.