#include <iostream>
#include <vector>
#include <list>
#include <algorithm>
#include <concepts>
#include <iterator>
#include <ranges>  

template<typename T>
void check(T arg)
{

}

int main()
{
	std::cout << std::boolalpha;

	std::vector<int> v = { 1,2,3 };
	std::list<int>   s = { 1,2,3 };
	int x[3] = { 1,2,3 };

	check(std::begin(v));
	check(std::begin(s));
	check(std::begin(x));

}