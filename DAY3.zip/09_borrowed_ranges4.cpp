#include <iostream>
#include <vector>
#include <ranges>
#include <string>
#include <string_view>

//
template<typename T>
inline constexpr bool enable_borrowed_range = false;

template<typename T> class take_view
{
	T& container;
	std::size_t count;
public:
	take_view(T& c, std::size_t sz) : container(c), count(sz) {}

	auto begin() { return container.begin(); }
	auto end() { return container.begin() + count; }
};

template<typename T>
concept borrowed_range = enable_borrowed_range<T>;
//-----------------------------------------------------------------

template<typename T> void check(T& c)
{
	std::cout << std::boolalpha;
	std::cout << std::ranges::borrowed_range<T> << std::endl;
}


int main()
{
	std::vector vec{ 1, 2, 3, 4, 5 };
	int arr[] = { 1,2,3,4,5 };
	std::string s{ "Hello" };
	std::string_view sv(s);
	std::ranges::take_view tv(vec, 3);

	check(vec); 
	check(arr); 
	check(s);
	check(sv); 
	check(tv);

}


