#include <iostream>
#include <vector>
#include <string>
#include <string_view>
#include <algorithm>

int main()
{
    // std::ranges �˰����� rvalue range �� �����ϴ� ���

    auto n = std::ranges::min(std::vector{5, 4, 3, 1, 2, 9});
    std::cout << n << std::endl; // 


    //
    auto p1 = std::ranges::find(std::vector{1, 2, 3}, 2);


    std::string s{ "Hello" };
    auto p2 = std::ranges::find(std::string_view{s}, 'e');
}