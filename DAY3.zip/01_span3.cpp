#include <iostream>
#include <vector>
#include <span>

void foo(int* arr)
{
}

int main()
{
    int x[10]{1,2,3,4,5,6,7,8,9,10};
    
    // std::vector<int> x{1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

    foo(x);
}