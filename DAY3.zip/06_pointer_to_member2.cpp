#include <iostream>

class Dialog
{
public:
	void close1(int a) {}
};

void foo(int a) {}

int main()
{
	void(*f1)(int) = &foo;
	void(*f2)(int) = &Dialog::close1;

}