#include <iostream>
#include <ranges>
#include <vector>

template<typename T> class take_view
{
	ref_view<T> container;
	std::size_t count;
public:
	take_view(T& c, std::size_t sz) : container(c), count(sz) {}

	auto begin() { return container.begin(); }
	auto end() { return container.begin() + count; }
};

template<typename T> class reverse_view
{
	ref_view<T> container;
public:
	reverse_view(T& c) : container(c) {}

	auto begin(){ return container.rbegin(); }
	auto end()	{ return container.rend(); }
};

int main()
{
	std::vector v = { 1,2,3,4,5,6,7,8,9,10 };

	take_view tv(v, 5);
	reverse_view rv(v);

	std::cout << tv.size() << std::endl;	
	std::cout << rv.size() << std::endl;

}