#include <iostream>
#include <ranges>

// std::ranges::size() �̾߱�

struct MyContainer1
{
	int* begin() { return 0; }
	int* end() { return 0; }
};

int main()
{
	MyContainer1 mc1;

	auto sz1 = std::size(mc1);
	auto sz2 = std::ranges::size(mc1);
}