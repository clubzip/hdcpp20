#include <iostream>
#include <ranges>
#include <vector>
#include <algorithm>

int main()
{
	std::vector v = { 1,2,3,4,5 };

	auto ret1 = std::find(v.begin(), v.end(), 3);

	auto ret2 = std::ranges::find(v, 3);
}