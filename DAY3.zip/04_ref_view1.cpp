#include <vector>
#include <iostream>
#include <ranges>

template<typename T> class ref_view
{
	T* src;
public:
	ref_view(T& cont) : src(&cont) {}

	auto begin() { return src->begin(); }
	auto end()   { return src->end(); }
	auto size()	 { return src->size(); }
};

int main()
{
	std::vector<int> v1 = { 1,2,3,4,5 };
	std::vector<int> v2 = { 1,2,3,4,5,6,7,8,9,10 };

	// 1. raw reference
	std::vector<int>& r1 = v1;
	std::vector<int>& r2 = v2;

	r1 = r2;

	// ����� ������ ������
	std::cout << v1.size() << std::endl;
	std::cout << v2.size() << std::endl;
	std::cout << r1.size() << std::endl;
	std::cout << r2.size() << std::endl;
}