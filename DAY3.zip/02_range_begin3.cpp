#include <iostream>
#include <ranges>

// std::ranges::begin �� ���� 3. 

struct SomeType
{
	int* begin() { return 0; }
};

int main()
{
	SomeType st;

	auto p1 = std::begin(st); 

	auto p2 = std::ranges::begin(st);
}
