#include <iostream>
#include <functional>

struct Point
{
	int x;
	int y;
};

int main()
{
	int n = 10;
	int* p1 = &n;


}