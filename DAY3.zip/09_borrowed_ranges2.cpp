#include <iostream>
#include <vector>
#include <string>
#include <string_view>
#include <ranges>

int main()
{
    std::string s = "hello";

    auto p1 = std::ranges::begin( std::vector{1,2,3} ); // ?
    auto p2 = std::ranges::begin(std::string_view{ s });// ? 
}
