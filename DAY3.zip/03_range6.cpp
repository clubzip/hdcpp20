#include <iostream>
#include <vector>
#include <ranges>
#include <algorithm>

// ������ ����

int main()
{
	std::vector v = { 1,2,3,4,5,6,7,8,9,10 };

	auto fv = v | std::views::filter([](int n) { return n % 2 == 0; });

	for (auto e : fv)
	{
		std::cout << e << ",  ";
	}
	std::cout << std::endl;
}


