
#include <iostream>
#include <algorithm>
#include <vector>
#include <ranges>

int main()
{
	std::vector v = { 1,2,3,4,5 };
//	int v[] = { 1,2,3,4,5 };

	// �ݺ��ڸ� ��� ���
	// 1. C++98
	auto p1 = v.begin();		


	// 2. C++11
	auto p2 = std::begin(v);	
	

	// 3. C++20
	auto p3 = std::ranges::begin(v);
}