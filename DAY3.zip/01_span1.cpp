#include <iostream>
#include <string>
#include <string_view>	// C++17

int main()
{
	std::string src = "to be or not to be";

	// string vs string_view
	std::string      ss1 = src;
	std::string_view sv1 = src;

	
	std::string      ss2 = "to be or not to be";
	std::string_view sv2 = "to be or not to be";
}