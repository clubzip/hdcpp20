#include <list>
#include <string>
#include <iostream>

class String : public std::string
{
public:
	using std::string::basic_string;

	~String() { std::cout << "~String" << std::endl; }
};

int main()
{
	{
		String s1 = "AA";
		std::cout << s1 << std::endl;

		std::cout << "in block" << std::endl;
	}

	std::cout << "out block" << std::endl;
}