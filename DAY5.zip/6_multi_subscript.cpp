#include <array>
#include <iostream>

// multi dimension subscript

int main()
{    
    std::array arr = { 1,2,3,4,5 };
    arr[0] = 10;

    array3d<int, 4, 3, 2> v;

    v[3, 2, 1] = 42;   
    
}