#include <list>
#include <string>
#include <iostream>

class String : public std::string
{
public:
	using std::string::basic_string;

	~String() { std::cout << "~String" << std::endl; }
};

template<typename T> 
T mymax(T a, T b)
{
	return a < b ? b : a;
}

int main()
{
	String s1 = "AA";
	String s2 = "BB";

	String s3 = mymax(s1, s2);

	std::cout << s3 << std::endl;
}