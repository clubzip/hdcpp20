#include <print>

int main()
{
	std::print("{0}, {1}\n", "kim", 20);
	std::println("{0}, {1}", "kim", 20);
}
