#include <iostream>

class less
{
public:
	bool operator()(int a, int b) 
	{
		return a < b;
	}
};

int main()
{
	less f;
	bool b = f(1, 2);
}